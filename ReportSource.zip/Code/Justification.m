num1 = [ 12.35 589 0 82];
num2 = [-5.25 0.8 8950 -0.09];

add = num1 + num2;
mul = num1 .* num2;
div = num1 ./ num2;

single(add)
single(mul)
single(div)